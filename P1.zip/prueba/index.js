const express = require('express');
const pool =require('./config/db');
const app= express();

app.use(express.json());

app.get('/api/productos', async (req, res)=>{
    try{
        const [rows]= await pool.query ('SELECT * FROM awos_tienda.productos');
        res.json(rows);
    }catch(error){
        console.log(error);
        res.status(500).json({error: 'Error al leer la BD'});
    }
});

//Método post para insert productos/api/productos
app.post('/api/productos', async (req, res)=>{
    const nuevoProducto={
        nombre: req.body.nombre,
        precio: req.body.precio,
        stock: req.body.stock
    };

    try{
        const [rows]= await pool.query (`INSERT INTO awos_tienda.productos (nombre, precio, stock) values ('${nuevoProducto.nombre}', ${nuevoProducto.precio}, ${nuevoProducto.stock})`);
        res.json(
            {mensaje: 'Producto agregado' }
        );

        if(nuevoProducto.nombre==null || nuevoProducto.nombre==''){
            return res,status(400).json({error: 'Ingrese un nombre'});
        }else if(!Number.isInteger(nuevoProducto.precio) || nuevoProducto.precio <=0){
            return res.status(400).json({error: 'El precio debe ser un entero mayor a 0'});
        }else if(!Number.isInteger (nuevoProducto.stock)){
            return res.status(400).json({error: 'El stock debe ser un numero entero'});
        }

    }catch(error){
        console.log(error);
        res.status(500).json({error: 'Error al agregar un producto'});
    }
})

//nombre obligatorio: no null, no string vacio
//precio : int y mayor a 0
//stock entero: no decimales
//descripcion(opcional): si envia, no mas de 255 caracteres

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>{
    console.log(`Server corriendo en puerto ${PORT}`);
})