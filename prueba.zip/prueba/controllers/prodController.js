const pool = require('../config/db'); //Solo se hace la importacion hacia la configuración de la BD

const getProductos = async (req, res)=>{  //Funcion landa
    try{  //dentro va la logica de negocios
        const [rows]= await pool.query('SELECT * FROM productos');
        res.json(rows);
    }catch(error){
        res.status(500).json({error: 'Error del servidor'});
    }
};

const createProducto = async (req, res)=>{
    
    const {nombre, precio, stock}= req.body;

    try{
        const [resultado]= await pool.query ('INSERT INTO productos (nombre, precio,stock) VALUES (???)');
        res.satus(201).json({id: resultado.insertId, nombre,precio, stock});

        if(nuevoProducto.nombre==null || nuevoProducto.nombre==''){
            return res.status(400).json({error: 'Ingrese un nombre'});
        }else if(!parseInt(nuevoProducto.precio) || nuevoProducto.precio <=0){
            return res.status(400).json({error: 'El precio debe ser un entero mayor a 0'});
        }else if(!parseInt (nuevoProducto.stock)){
            return res.status(400).json({error: 'El stock debe ser un numero entero'});
        }
    }catch(error){
        res.status(500).json({mensaje: 'Error al guardar'});
    }
}

const putProducto = async (req, res)=>{
    const idBusqueda= parseInt (req.params.id);
    const {precio, stock}= req.body;

    try{

        const [rows]= await pool.query (`UPDATE awos_tienda.productos SET precio= ${precio}, stock= ${stock} WHERE id= ${idBusqueda}`);
        if(rows.affectedRows===0){
            return  res.status(404).json ({error: "Producto no encontrado"});
        }
        res.json(
            {mensaje: 'Producto Modificado'}
        );


        
    }catch(error){
        console.log(error);
        res.status(500).json({error: 'Error al modificar producto'});
    }
}

const deleteProducto = async (req, res)=>{
    const idBusqueda= parseInt(req.params.id);

    try{
        const [rows]= await pool.query (`DELETE FROM awos_tienda.productos WHERE id= ${idBusqueda}`);
        res.json(
            {mensaje:'Producto eliminado' }
        );
    }catch(error){
        console.log(error);
        res.status(500).json({error: 'Error al eliminar producto'});
    }
}



module.exports= {getProductos, createProducto, putProducto, deleteProducto};