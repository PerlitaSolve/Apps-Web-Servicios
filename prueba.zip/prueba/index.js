/*const express = require('express');
const pool =require('./config/db');
const app= express();

app.use(express.json());

//Método get (MOSTRAR LA LSITA DE PRODUCTOS)
app.get('/api/productos', async (req, res)=>{
    try{
        const [rows]= await pool.query ('SELECT * FROM awos_tienda.productos');
        res.json(rows);
    }catch(error){
        console.log(error);
        res.status(500).json({error: 'Error al leer la BD'});
    }
});

//Método post para insert productos/api/productos
app.post('/api/productos', async (req, res)=>{
    const nuevoProducto={
        nombre: req.body.nombre,
        precio: req.body.precio,
        stock: req.body.stock
    };

    try{
        const [rows]= await pool.query (`INSERT INTO awos_tienda.productos (nombre, precio, stock) values ('${nuevoProducto.nombre}', ${nuevoProducto.precio}, ${nuevoProducto.stock})`);
        res.json(
            {mensaje: 'Producto agregado' }
        );

        if(nuevoProducto.nombre==null || nuevoProducto.nombre==''){
            return res.status(400).json({error: 'Ingrese un nombre'});
        }else if(!parseInt(nuevoProducto.precio) || nuevoProducto.precio <=0){
            return res.status(400).json({error: 'El precio debe ser un entero mayor a 0'});
        }else if(!parseInt (nuevoProducto.stock)){
            return res.status(400).json({error: 'El stock debe ser un numero entero'});
        }

    }catch(error){
        console.log(error);
        res.status(500).json({error: 'Error al agregar un producto'});
    }
})

//nombre obligatorio: no null, no string vacio
//precio : int y mayor a 0
//stock entero: no decimales
//descripcion(opcional): si envia, no mas de 255 caracteres



//Método put (MODIFICAR)
app.put('/api/productos/:id', async(req, res)=>{
    const idBusqueda= parseInt (req.params.id);

    const modificado={
        precio: req.body.precio,
        stock: req.body.stock
    };

    try{

        const [rows]= await pool.query (`UPDATE awos_tienda.productos SET precio= ${modificado.precio}, stock= ${modificado.stock} WHERE id= ${idBusqueda}`);
        if(rows.affectedRows===0){
            return  res.status(404).json ({error: "Producto no encontrado"});
        }
        res.json(
            {mensaje: 'Producto Modificado'}
        );


        
    }catch(error){
        console.log(error);
        res.status(500).json({error: 'Error al modificar producto'});
    }
})

//Método delete(BORRAR PRODUCTOS)
app.delete('/api/productos/:id', async(req, res)=>{
    const idBusqueda= parseInt(req.params.id);

    try{
        const [rows]= await pool.query (`DELETE FROM awos_tienda.productos WHERE id= ${idBusqueda}`);
        res.json(
            {mensaje:'Producto eliminado' }
        );
    }catch(error){
        console.log(error);
        res.status(500).json({error: 'Error al eliminar producto'});
    }
    
})

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>{
    console.log(`Server corriendo en puerto ${PORT}`);
})*/

const express = require('express');
const app = express();
require('dotenv').config();
const productoRoutes = require('./routes/route'); // utilizar controller

app.use(express.json());

app.use('/api/productos', productoRoutes);

const PORT = process.envPORT || 4000;
app.listen(PORT, ()=> console.log(`App escuchando en puerto ${PORT}`));

